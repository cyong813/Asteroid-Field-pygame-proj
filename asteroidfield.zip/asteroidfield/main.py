import math
import pygame
import entity
import ship

# The player movement area is a unit circle scaled to match the size of the
# window.  A margin can also be set here so the movement area does not bump
# right up against the window border.
MOVEMENT_AREA_MARGIN = 0.5

# Every physics tick will assume this framerate, and the actual rendering will
# not happen any faster than this.
FRAMERATE = 30.0

windowSize = (400, 300)
target = (0, 0)

pygame.init()

pygame.display.set_caption("Asteroid Field")
ship = ship.Ship(pygame.image.load("Ship.png"), 1200)
surface = pygame.display.set_mode(windowSize, pygame.RESIZABLE)

def draw(surface):
	size = surface.get_size()
	center = (size[0]/2, size[1]/2)
	pixelsPerUnit = min(size)/(1+MOVEMENT_AREA_MARGIN)/2
	pygame.draw.circle(surface, (255, 255, 255), center, int(pixelsPerUnit), int(pixelsPerUnit*.01)+1)
	ship.draw(surface, pixelsPerUnit)

clock = pygame.time.Clock()

while not pygame.event.peek(pygame.QUIT):
	timestep = clock.tick_busy_loop(FRAMERATE)
	ship.update(float(timestep)/1000, target)
	
	resizes = pygame.event.get(pygame.VIDEORESIZE)
	if resizes:
		windowSize = resizes[-1].size
		surface = pygame.display.set_mode(windowSize, pygame.RESIZABLE)
	
	movements = pygame.event.get(pygame.MOUSEMOTION)
	if movements:
		size = surface.get_size()
		center = (size[0]/2, size[1]/2)
		pixelsPerUnit = min(size)/(1+MOVEMENT_AREA_MARGIN)/2
		mouseX = movements[-1].pos[0]
		mouseY = movements[-1].pos[1]
		target = ((mouseX-center[0])/pixelsPerUnit, (mouseY-center[1])/pixelsPerUnit)
		
		
	
	surface.fill((0, 0, 0)) # Clear the previous frame.
	
	draw(surface)
	pygame.display.flip()
